#pragma once

#include "Head/LoadDiagram.h"

Camera* camera;
Projection* proj;

#define MAX_INDEX 12
#define MAX_INDEX13 2

#define ID_TRI 0
#define ID_RECT 1
#define ID_PENTA 2
#define ID_OCTA 3

#define PROJED true


GLvoid Mouse(int button, int state, int x, int y);
GLvoid Keyboard(unsigned char key, int x, int y);
GLvoid specialKeyboard(int key, int x, int y);






Diagram playground;


bool depthed = true;
bool gopersepective = true;
bool gospin[2] = { false, false };
bool direct = true;
bool goorbit = false;
bool endorbit = false;
bool checkPoint = false;
bool goStretch = false;
bool goSpiral = false;
bool spinSequence = false;


float base_axis[6][3] = {
	-1.0f, 0.0f, 0.0f,
	1.0f, 0.0f, 0.0f,
	0.0f, -1.0f, 0.0f,
	0.0f, 1.0f, 0.0f,
	0.0f, 0.0f, -1.0f,
	0.0f, 0.0f, 1.0f
};

float base_axis_col[6][3] = {
	1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
	0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
	0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f
};

int baseAxisIndex = 0;
int mulcount = 1;


GLvoid Setplayground() {

	playground.center = {0.0f, 0.0f, 0.0f};

	playground.radian = { 0.0f, 0.0f, 0.0f };

	playground.Stretch = { 0.2f, 0.2f, 0.2f };

	playground.Orbit = { 0.0f, 0.0f, 0.0f };

	playground.postype = ID_TRI;
}


GLvoid SetCamera() {
	delete camera;

	camera = new Camera(glm::vec3(0.0f, 0.0f, 90.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
}

GLvoid SetProjection(int projtype) {
	delete proj;

	proj = new Projection();

	if (projtype == PROJ_ORTHO) {
		proj->InitOrtho(-5.0f, 5.0f, 5.0f, -5.0f, -30.0f, 15.0f);
	}
	else {
		proj->InitPerspective(glm::radians(160.0f), 1.0f, 0.1f, 100.0f);
	}

	IsobjsProjed(false);
}

void DepthCheck() {
	if (depthed)
		glEnable(GL_DEPTH_TEST);
	else
		glDisable(GL_DEPTH_TEST);
}

void Setindex() {
	int* p1 = tri->AddIndexList();
	int* p2 = rect->AddIndexList();

	cout << sizeof((p1));

	int present_bit = index_count;
	int cnt = 0;
	int begin = cnt;




	for (index_count; index_count < 3; index_count++) {
		index[index_count] = p1[index_count];

		cnt++;
	}

	tri->start_index = 0;
	//cnt += 36;

	present_bit = index_count;

	begin = cnt;

	rect->start_index = index_count;

	for (index_count; index_count < present_bit + 6; index_count++) {
		index[index_count] = 3 + p2[index_count - begin];

		cnt++;
	}

	//cnt += 12;

	present_bit = index_count;
	begin = cnt;

	//pyr->start_index = index_count;

	//for (index_count; index_count < present_bit + 18; index_count++) {
	//	index[index_count] = 12 + p3[index_count - begin];
	//}

	cnt += 15;


	//present_bit = index_count;
	//baseAxisIndex = index_count;

	//for (index_count; index_count < present_bit + 6; index_count++, index_array_count++) {
	//	index[index_count] = 12 + 5 + index_array_count;
	//}



	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(index), index, GL_DYNAMIC_DRAW);

	free(p1);
	free(p2);
}

MyObjCol SetRandObjCol() {
	MyObjCol coltoken = { (float)((float)rand() / RAND_MAX), (float)((float)rand() / RAND_MAX), (float)((float)rand() / RAND_MAX) };

	return coltoken;
}



GLvoid SetBuffer() {
	MyObjCol mycol[8];
	MyObjCol mycol2[4];
	MyObjCol mycol3[5];

	MyObjCol coltoken = SetRandObjCol();

	for (int i = 0; i < 3; i++) {
		mycol[i] = coltoken;
	}
	coltoken = SetRandObjCol();

	for (int i = 0; i < 4; i++) {
		mycol2[i] = coltoken;
	}
	coltoken = SetRandObjCol();

	for (int i = 0; i < 5; i++) {
		mycol3[i] = coltoken;
	}

	tri->Setcol(mycol);
	rect->Setcol(mycol2);
	//pyr->Setcol(mycol3);

	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	//glBufferData(GL_ARRAY_BUFFER, 18 * sizeof(GLfloat), NULL, GL_DYNAMIC_DRAW);
	glBufferData(GL_ARRAY_BUFFER, (MAX_INDEX * 10000) * sizeof(GLfloat), NULL, GL_DYNAMIC_DRAW);
	tri->SetPos();
	rect->SetPos();
	//pyr->SetPos();

	//float* counter = new FLOAT();
	int* counter = new INT();
	(*counter) = 0;
	int type = 0;




	for (int i = 0; i < 3; i++) {
		glBufferSubData(GL_ARRAY_BUFFER, (*counter),
			3 * sizeof(GLfloat), tri->pos[i]);

		(*counter) += 3 * sizeof(GLfloat);
	}


	for (int i = 0; i < 4; i++) {
		glBufferSubData(GL_ARRAY_BUFFER, (*counter),
			3 * sizeof(GLfloat), rect->pos[i]);

		(*counter) += 3 * sizeof(GLfloat);
	}

	//for (int i = 0; i < 5; i++) {
	//	glBufferSubData(GL_ARRAY_BUFFER, (*counter),
	//		3 * sizeof(GLfloat), pyr->pos[i]);

	//	(*counter) += 3 * sizeof(GLfloat);
	//}



	for (int i = 0; i < 6; i++) {
		glBufferSubData(GL_ARRAY_BUFFER, (*counter),
			3 * sizeof(GLfloat), base_axis[i]);

		(*counter) += 3 * sizeof(GLfloat);
	}

	/*index_count = 0;
	index_array_count = 0;*/

	Setindex();



	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, (MAX_INDEX * 10000) * sizeof(GLfloat), NULL, GL_DYNAMIC_DRAW);




	(*counter) = 0;


	for (int i = 0; i < 3; i++) {


		glBufferSubData(GL_ARRAY_BUFFER, (*counter),
			3 * sizeof(GLfloat), tri->col[i]);

		(*counter) += 3 * sizeof(GLfloat);

		//cout << "(" << cube.pos[i][0] << ", " << cube.pos[i][1] << ", " << cube.pos[i][2] << ')' << endl << endl;
	}

	for (int i = 0; i < 4; i++) {
		glBufferSubData(GL_ARRAY_BUFFER, (*counter),
			3 * sizeof(GLfloat), rect->col[i]);

		(*counter) += 3 * sizeof(GLfloat);
	}

	//for (int i = 0; i < 5; i++) {
	//	glBufferSubData(GL_ARRAY_BUFFER, (*counter),
	//		3 * sizeof(GLfloat), pyr->col[i]);

	//	(*counter) += 3 * sizeof(GLfloat);
	//}




	//for (int i = 0; i < 6; i++) {
	//	glBufferSubData(GL_ARRAY_BUFFER, (*counter),
	//		3 * sizeof(GLfloat), base_axis_col[i]);

	//	(*counter) += 3 * sizeof(GLfloat);
	//}

	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
}





void main(int argc, char** argv) { //--- ������ ����ϰ� �ݹ��Լ� ���� { //--- ������ �����ϱ�
	srand(time(NULL));

	glutInit(&argc, argv); // glut �ʱ�ȭ
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH); // ���÷��� ��� ����
	glutInitWindowPosition(0, 0); // �������� ��ġ ����
	glutInitWindowSize(Screensize.x, Screensize.y); // �������� ũ�� ����
	glutCreateWindow("Example1"); // ������ ����
	//--- GLEW �ʱ�ȭ�ϱ�
	glewExperimental = GL_TRUE;
	if (glewInit() != GLEW_OK) // glew �ʱ�ȭ
	{
		std::cerr << "Unable to initialize GLEW" << std::endl
			;
		exit(EXIT_FAILURE);
	}
	else
		cout << "GLEW Initialized\n";

	make_vertexShaders();
	make_fragmentShaders();
	make_shaderProgram();
	InitBuffer();


	glBindVertexArray(vao);
	SetBuffer();
	Setplayground();
	SetCamera();
	SetProjection(PROJ_PERSPECTIVE);
	tri->SetTranPos(20);
	rect->SetTranPos(20);
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glEnable(GL_DEPTH_TEST);


	glutDisplayFunc(drawScene); // ��� �Լ��� ����
	glutReshapeFunc(Reshape); // �ٽ� �׸��� �Լ� ����
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(specialKeyboard);
	glutMouseFunc(Mouse);








	glutMainLoop(); // �̺�Ʈ ó�� ����


}



float radian = 10.0f;
int mycnt = 0;
glm::vec3 allAxis = glm::vec3(0.0f, 0.0f, 0.0f);

void drawScene()
{


	glClearColor(mycolor.red, mycolor.green, mycolor.blue, mycolor.alpha);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//gluLookAt(0.0, 0.0, 100.0f, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

	glUseProgram(shaderProgramID);
	glm::mat4 basemat = glm::mat4(1.0f);
	glm::mat4 rm = basemat;
	glm::mat4 rm2 = basemat;
	glm::mat4 model = basemat;
	glm::mat4 submodel = basemat;
	//glm::mat4 rm3 = glm::mat4(1.0f);

	/*model = glm::translate(model, glm::vec3(0.1f, 0.5f, 0.0f));*/
	int modelLocation = glGetUniformLocation(shaderProgramID, "modelTransform");

	glBindVertexArray(vao);




	int counter = 0;



	for (int i = 0; i < 2; i++) {

		gluQuadricDrawStyle(qobj, playground.qset.drawstyle);
		gluQuadricNormals(qobj, playground.qset.normals);
		gluQuadricOrientation(qobj, playground.qset.orientation);



		glm::mat4 projection = glm::mat4(1.0);
		projection = proj->GetProjMatrix();
		unsigned int projectionLocation = glGetUniformLocation(shaderProgramID, "projectionTransform");
		glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);


		glm::mat4 view = glm::mat4(1.0);
		view = camera->GetViewMatix();
		unsigned int viewLocation = glGetUniformLocation(shaderProgramID, "viewTransform");
		glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);



		model *= InitRotateProj(playground.Orbit, { 0.0f, 0.0f, 0.0f });
		model *= InitRotateProj(playground.radian, playground.center);
		model *= InitMoveProj(playground.center);
		//model *= InitScaleProj(playground.Stretch);
		//glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(model));








		switch (playground.postype) {
		case ID_TRI:
			counter = tri->start_index;
			submodel = model;

			submodel *= tri->GetWorldTransMatrix();
			glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(submodel));

			glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, (void*)(counter * sizeof(GLfloat)));
			counter += 3;




			//glDrawElements(GL_TRIANGLES, 6 * 6, GL_UNSIGNED_INT, (void*)(cube->start_index * sizeof(GLfloat)));
			break;
		case ID_RECT:
			glDrawElements(GL_TRIANGLES, 3 * 4, GL_UNSIGNED_INT, (void*)(tri->start_index * sizeof(GLfloat)));
			break;
		case ID_PENTA:
			counter = rect->start_index;
			submodel = model;
			submodel *= rect->GetWorldTransMatrix();
			glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(submodel));
			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, (void*)(counter * sizeof(GLfloat)));

			break;
		case ID_OCTA:
			//gluSphere(qobj, sphere->radius, sphere->slices, sphere->stacks);
			break;

			model = basemat;
		}
	}







	//model = basemat;


	//model = rm2 * rm;

	//glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(model));

	//glDrawElements(GL_LINES, 6, GL_UNSIGNED_INT, (void*)(baseAxisIndex * sizeof(GLfloat)));
	//counter += 6 * sizeof(GLint);




	glutSwapBuffers();

}

GLvoid Reshape(int w, int h) { //--- �ݹ� �Լ�: �ٽ� �׸��� �ݹ� �Լ� {
	glViewport(0, 0, w, h);
}


GLvoid Mouse(int button, int state, int x, int y) {


	glutPostRedisplay();
}




GLvoid Keyboard(unsigned char key, int x, int y) {

	int token = (int)key - (int)'1';
	int randnum[2];
	randnum[0] = -1, randnum[1] = -1;
	GLPos firsttoken = { 0.0f, 0.8f, 0.0f };

	switch (key) {
	case 'w': case 'W':
		if ((int)key - (int)'a' < 0) {
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			for (int i = 0; i < 2; i++) {
				playground.qset.drawstyle = GLU_FILL;
			}

		}
		else {
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			for (int i = 0; i < 2; i++) {
				playground.qset.drawstyle = GLU_LINE;
			}
		}

		break;

	
	
	case 'm':
		goorbit = false;
		gospin[0] = false;
		gospin[1] = false;
		goStretch = false;
		goSpiral = false;
		Setplayground();
		break;



	case 'q':
		delete rect;
		delete tri;
		//delete pyr;

		glutLeaveMainLoop();
		break;

	default:
		break;
	}

	glutPostRedisplay();
}

GLvoid specialKeyboard(int key, int x, int y) {
	switch (key) {
	case GLUT_KEY_LEFT:
		playground.center -= {1.0f, 0.0f, 0.0f};
		break;
	case GLUT_KEY_RIGHT:
		playground.center += {1.0f, 0.0f, 0.0f};
		break;
	case GLUT_KEY_UP:
		playground.center -= {0.0f, 1.0f, 0.0f};
		break;
	case GLUT_KEY_DOWN:
		playground.center += {0.0f, 1.0f, 0.0f};
		break;
	}

	glutPostRedisplay();
}



GLvoid MyCcw(int value) {

	playground.radian.x += (playground.axis.x * 5);

	playground.radian.y += (playground.axis.y * 5);

	playground.radian.z += (playground.axis.z * 5);




	if (gospin[value] && direct) {
		glutTimerFunc(10, MyCcw, value);
	}
	else if (gospin[1 - value] && direct) {
		glutTimerFunc(10, MyCcw, 1 - value);
	}
	glutPostRedisplay();
}

GLvoid MyCw(int value) {

	playground.radian.x -= (playground.axis.x * 5);

	playground.radian.y -= (playground.axis.y * 5);

	playground.radian.z -= (playground.axis.z * 5);

	if (playground.radian.x <= -180)
		cout << "pause" << endl << endl;


	if (gospin[value] && direct == false) {
		glutTimerFunc(10, MyCw, value);
	}

	else if (gospin[1 - value] && direct == false) {
		glutTimerFunc(10, MyCw, 1 - value);
	}

	glutPostRedisplay();
}


GLvoid OrbitCcw(int value) {

	playground.Orbit += Vec3ToGLPos(playground.OrbitAxis) * 5;

	if (goorbit && playground.orbitccw) {
		glutTimerFunc(30, OrbitCcw, value);
	}
	glutPostRedisplay();
}





GLvoid OrbitCw(int value) {
	playground.Orbit -= Vec3ToGLPos(playground.OrbitAxis) * 5;


	if (goorbit && playground.orbitccw == false) {

		if (endorbit && playground.Orbit.y <= -180) {
			playground.center = playground.target;
			playground.Orbit = 0.0f;

			//glm::mat4 result = glm::mat4(1.0);

			//result *= InitRotateProj(playground[value].Orbit, { 0.0f, 0.0f, 0.0f });
			//result *= InitMoveProj(playground[value].center);
			//result *= InitScaleProj(playground[value].Stretch);

			//playground[value].center = GetProjedPos(playground[value].center, result);
			//playground[value].Orbit = 0.0f;
		}
		else
			glutTimerFunc(30, OrbitCw, value);
	}
	glutPostRedisplay();
}



